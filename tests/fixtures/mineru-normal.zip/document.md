# A synthetic document
The result is l2 units.
