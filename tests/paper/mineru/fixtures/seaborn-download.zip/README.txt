MinerU output

native/mineru.zip is the unchanged archive returned by MinerU, with its original
file names, paths and contents. Use it to inspect the native processor output.
Archives containing PDF members are rejected to avoid retaining original or
debug PDFs in the saved result.

The root files are compatibility exports: Markdown, middle JSON and model JSON
keep their contents under DocZyme names; content-list JSON uses MinerU's own
renderers. The images directory preserves the extracted image files.
DocZyme does not generate a summary or rewrite the extracted prose.
